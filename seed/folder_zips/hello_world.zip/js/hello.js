var foo = 'bar';

